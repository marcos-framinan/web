const nombre= "Marcos";
let edad= 16;
let esEstudiante= true;
function hola(){
    alert("hola ", nombre);
    t1= document.getElementById("texto1");
    nomb= t1.value;
    document.getElementById("texto2").value = "hola " + nomb;
}
console.log("marcos", nombre )
console.log("16", edad)
console.log(esEstudiante)


let n1 = 24
let n2 = 4
let sum= n1 + n2
function sumar (){
    alert("la suma es ", sum);
    n1= document.getElementById("texto3");
    n2=document.getElementById("texto4");
    sum=parseInt(n1.value) + parseInt(n2.value);
    document.getElementById("texto5").value = "la suma es " + sum;
        
}
function restar (){
    alert("la resta es ", resta);
    n3= document.getElementById("texto6");
    n4=document.getElementById("texto7");
    resta=n3.value - n4.value;
    document.getElementById("texto8").value = "la resta es " + resta;
        
 

}
let resta = n1-n2;
let n3= 24
let n4= 4

function multiplicar (){
    alert("la multiplicación es ", mult);
    n5= document.getElementById("texto9");
    n6=document.getElementById("texto10");
    mult=n5.value * n6.value;
    document.getElementById("texto11").value = "la multiplicacion es " + mult;
        
}
let mult = n1 * n2
let n5= 24
let n6= 4




function dividir (){
    alert("la division es ", div);
    n7= document.getElementById("texto12");
    n8=document.getElementById("texto13");
    div=n7.value/ n8.value;
    document.getElementById("texto14").value = "la division es " + div;
}
let n7= 24
let n8= 4
let div = n1 / n2;

console.log(n1, "+,", n2, "=",sum);
console.log(n1, "-", n2, "=",resta);
console.log(n1, "*", n2, "=",mult);
console.log(n1, "/", n2, "=",div)


edad = 16
if (edad >=18)
{
    console.log ("eres mayor de edad")

}
else
{
    console.log ("eres menor de edad");
}

function saludar (nombre) {
    return "hola, " + nombre;
}
    
console.log (saludar("marcos"));


function dame_hora()
{
    return new Date().toLocaleTimeString()
}
console.log("la hora es", dame_hora())