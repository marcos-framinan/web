document.getElementById("botonAlerta").onclick = function() {
    alert("¡Has hecho clic en el botón!");
};

const imagen = document.getElementById("imagen");
const botonCambiar = document.getElementById("botonCambiar");

const img1 = "https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=400&q=80";
const img2 = "https://images.unsplash.com/photo-1760029012684-7cc3800aba71?ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&q=80&w=686";

botonCambiar.onclick = function() {
    if(imagen.src.includes(img1)) {
        imagen.src = img2;
    } else {
        imagen.src = img1;
    }
};

const botonEdad = document.getElementById("botonEdad");
const inputFecha = document.getElementById("fecha");
const resultado = document.getElementById("resultadoEdad");

botonEdad.onclick = function() {
    const fechaNacimiento = new Date(inputFecha.value);
    if (isNaN(fechaNacimiento)) {
        resultado.textContent = "Por favor, selecciona una fecha válida.";
        resultado.style.color = "red";
        return;
    }

    const hoy = new Date();
    let edad = hoy.getFullYear() - fechaNacimiento.getFullYear();
    const mes = hoy.getMonth() - fechaNacimiento.getMonth();
    const dia = hoy.getDate() - fechaNacimiento.getDate();
    if(mes < 0 || (mes === 0 && dia < 0)) {
        edad--;
    }

    if(edad >= 18) {
        resultado.textContent = `Tienes ${edad} años. Eres mayor de edad.`;
        resultado.style.color = "green";
    } else {
        resultado.textContent = `Tienes ${edad} años. No eres mayor de edad.`;
        resultado.style.color = "orange";
    }
};
